#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv) {
  int val;

  if (argc != 2) {
    printf("usage: a.out <descriptor#>!\n");
    return 0;
  }

  if ((val = fcntl(atoi(argv[1]), F_GETFL, 0)) < 0) {
    printf("fcntl error for %d!\n", atoi(argv[1]));
    return 0;
  }

  switch (val & O_ACCMODE) {
  case O_RDONLY:
    printf("read only!\n");
    break;
  case O_WRONLY:
    printf("write only!\n");
    break;
  case O_RDWR:
    printf("read write!\n");
    break;
  default:
    printf("unknown access mode!\n");
    return 0;
  }

  return 0;
}