#include <pthread.h>
#include <stdio.h>
#include <sys/prctl.h>
#include <syslog.h>

void *thread_proc(void *argv) {
  (void *)argv;

  prctl(PR_SET_NAME, "sub");

  openlog("sub", LOG_PID, LOG_CRON);
  syslog(LOG_INFO, "sub proc.");

  return NULL;
}

int main(int argc, char **argv) {
  pthread_t pid;

  openlog("main", LOG_PID, LOG_USER);
  syslog(LOG_INFO, "main start.");

  pthread_create(&pid, NULL, thread_proc, NULL);
  pthread_detach(pid);

  sleep(10);
  syslog(LOG_INFO, "main end.");

  while (1) {
    sleep(5);
  }

  return 0;
}