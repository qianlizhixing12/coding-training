#include <stdio.h>
#include <unistd.h>

#define BUFSIZE 512

int main(int argc, char **argv) {
  int n;
  char buf[BUFSIZE];

  while ((n = read(STDIN_FILENO, buf, BUFSIZE)) > 0) {
    if (write(STDOUT_FILENO, buf, n) != n) {
      printf("write error!\n");
      return 0;
    }
  }

  if (n < 0) {
    printf("read error!\n");
    return 0;
  }

  return 0;
}