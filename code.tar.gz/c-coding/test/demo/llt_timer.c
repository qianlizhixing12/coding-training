#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <signal.h>
#include <time.h>

void timer_proc(void *argv) {
  lgtm_log_info("log timer do argv[%s].", (char *)argv);
}

int main(int argc, char *argv[]) {
  lgtm_timer_handle *timer_hd1 = NULL;
  ret = lgtm_timer_create("timer_test1", 10, timer_proc, "aaa", &timer_hd1);
  if (ret != LGTM_OK) {
    return ret;
  }

  ret = lgtm_timer_start(timer_hd1);
  if (ret != LGTM_OK) {
    return ret;
  }

  lgtm_timer_handle *timer_hd2 = NULL;
  ret = lgtm_timer_create("timer_test2", 5, timer_proc, "bbb", &timer_hd2);
  if (ret != LGTM_OK) {
    return ret;
  }
  ret = lgtm_timer_start(timer_hd2);
  if (ret != LGTM_OK) {
    return ret;
  }
}