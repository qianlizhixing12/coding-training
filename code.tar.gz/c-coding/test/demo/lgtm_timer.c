#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/timerfd.h>
#include <errno.h>

#include "lgtm_log.h"
#include "lgtm_timer.h"

typedef struct {
  char name[LGTM_NAME_MAX];
  lgtm_timer_callback *proc;
  void *argv;
  uint interval;
  timer_t timerid;
} lgtm_timer_handle;

void lgtm_timer_callback_inner_thread(sigval_t sevp) {
  lgtm_timer_handle *timer_hd = (lgtm_timer_handle *)(sevp.sival_ptr);
  if (timer_hd == NULL || timer_hd->proc == NULL) {
    return;
  }

  timer_hd->proc(timer_hd->argv);
}

void lgtm_timer_callback_inner_sigv(int value) {
  lgtm_log_debug("@Jalyn debug -----> value:%d", value);
}

int lgtm_timer_create(char *name, uint interval, lgtm_timer_callback proc,
                      void *argv, lgtm_ptr *timer_hd) {
  if (name == NULL || name[0] == '\0') {
    lgtm_log_error("lgtm timer create error: name is empty!");
    return LGTM_ERR;
  } else if (strlen(name) >= LGTM_NAME_MAX) {
    lgtm_log_error("lgtm timer create error: name is too long!");
    return LGTM_ERR;
  }

  if (proc == NULL) {
    lgtm_log_error("lgtm timer create error: name[%s] porc is empty!", name);
    return LGTM_ERR;
  }

  if (interval <= 0) {
    lgtm_log_error("lgtm timer create error: name[%s] interval is vilid!",
                   name);
    return LGTM_ERR;
  }

  lgtm_timer_handle *timer_handle =
      (lgtm_timer_handle *)malloc(sizeof(lgtm_timer_handle));
  if (timer_handle == NULL) {
    lgtm_log_error("lgtm timer create error: name[%s] create handle fail!",
                   name);
    return LGTM_ERR;
  }
  memset(timer_handle, 0, sizeof(lgtm_timer_handle));
  strncpy(timer_handle->name, name, LGTM_NAME_MAX - 1);
  timer_handle->proc = proc;
  timer_handle->argv = argv;
  timer_handle->interval = interval;
  timer_handle->timerid = NULL;

  struct sigevent sevp;
  memset(&sevp, 0, sizeof(sevp));

  // 信号回调处理方式
  // sevp.sigev_notify = SIGEV_SIGNAL;
  // sevp.sigev_signo = SIGUSR1;
  // signal(SIGUSR1, lgtm_timer_callback_inner_sigv);

  sevp.sigev_notify = SIGEV_THREAD;
  sevp.sigev_notify_function = lgtm_timer_callback_inner_thread;
  sevp.sigev_value.sival_ptr = (void *)timer_handle;

  if (timer_create(CLOCK_MONOTONIC, &sevp, &(timer_handle->timerid))) {
    lgtm_log_error("lgtm timer create error: name[%s] create timer fail!",
                   name);
    free(timer_handle);
    return LGTM_ERR;
  }

  *timer_hd = timer_handle;

  return LGTM_OK;
}

int lgtm_timer_start(lgtm_ptr timer_hd) {
  if (timer_hd == NULL) {
    lgtm_log_error("lgtm timer start error:  timer handle is null!");
    return LGTM_ERR;
  }

  struct itimerspec ts = {
      {timer_hd->interval, 0},
      {timer_hd->interval, 0},
  };

  if (timer_settime(timer_hd->timerid, TIMER_ABSTIME, &ts, NULL) != 0) {
    lgtm_log_error("lgtm timer start error: name[%s] timer set fail!",
                   timer_hd->name);
    return LGTM_ERR;
  }

  return LGTM_OK;
}
