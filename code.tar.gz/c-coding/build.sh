export ROOTDIR=/home/nxx/c-coding
export BUILDDIR=${ROOTDIR}/build
export OUTPUTDIR=${ROOTDIR}/output

if [ -d ${BUILDDIR} ]; then
  rm -rf ${BUILDDIR}
fi
mkdir ${BUILDDIR}

if [ -d ${OUTPUTDIR} ]; then
  rm -rf ${OUTPUTDIR}
fi
mkdir ${OUTPUTDIR}

pushd ${BUILDDIR}
cmake3 ${ROOTDIR} -DCMAKE_INSTALL_PREFIX=${OUTPUTDIR}
make -j32 && make install
# make -j32 VERBOSE=1 && make install
popd

# run frame_main
cd ${OUTPUTDIR}/bin/
export LD_LIBRARY_PATH=/home/nxx/c-coding/output/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=${OUTPUTDIR}/lib:$LD_LIBRARY_PATH
export LGTM_LOG=lgtm_log.log
./main