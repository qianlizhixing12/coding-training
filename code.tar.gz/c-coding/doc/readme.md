### cmake demo

