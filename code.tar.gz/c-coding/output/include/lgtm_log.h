#ifndef __LGTM_LOG_H__
#define __LGTM_LOG_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#include "lgtm_config.h"

#define LGTM_LOG_DEBUG 0
#define LGTM_LOG_INFO 1
#define LGTM_LOG_WARN 2
#define LGTM_LOG_ERROR 3

#define lgtm_log_debug(format, ...)                                            \
  lgtm_log_write(LGTM_LOG_DEBUG, format, ##__VA_ARGS__)
#define lgtm_log_info(format, ...)                                             \
  lgtm_log_write(LGTM_LOG_INFO, format, ##__VA_ARGS__)
#define lgtm_log_warn(format, ...)                                             \
  lgtm_log_write(LGTM_LOG_WARN, format, ##__VA_ARGS__)
#define lgtm_log_error(format, ...)                                            \
  lgtm_log_write(LGTM_LOG_ERROR, format, ##__VA_ARGS__)

int lgtm_log_init();
void lgtm_log_write(uint level, const char *format, ...);
void lgtm_log_flush(void *argv);
void *lgtm_log_get();

#ifdef __cplusplus
}
#endif

#endif /* __LGTM_LOG_H__*/
