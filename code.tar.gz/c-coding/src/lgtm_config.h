#ifndef __LGTM_CONFIG_H__
#define __LGTM_CONFIG_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>

#define LGTM_VERSION "@VERSION@"

#define MAIN_SLEEP_TIME 5

#define LGTM_NAME_MAX 64
#define LGTM_PATH_MAX 256

#define LGTM_OK 0
#define LGTM_ALLOC 1
#define LGTM_ERR -1

typedef unsigned int uint;
typedef unsigned char uchar;

typedef void *lgtm_ptr;

#ifdef __cplusplus
}
#endif

#endif