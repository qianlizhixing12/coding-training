#ifndef __LGTM_TIMER_H__
#define __LGTM_TIMER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#include "lgtm_config.h"

typedef void(lgtm_timer_callback)(void *argv);

int lgtm_timer_create(char *name, uint interval, lgtm_timer_callback proc,
                      void *argv, int epoll_fd, lgtm_ptr *timer_hd);
int lgtm_timer_start(lgtm_ptr timer_hd);

#ifdef __cplusplus
}
#endif

#endif /* __LGTM_TIMER_H__*/
