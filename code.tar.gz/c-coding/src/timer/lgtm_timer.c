#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/timerfd.h>
#include <sys/epoll.h>
#include <errno.h>

#include "lgtm_log.h"
#include "lgtm_timer.h"

typedef struct {
  char name[LGTM_NAME_MAX];
  lgtm_timer_callback *proc;
  void *argv;
  uint interval;
  lgtm_timer_callback *callback;
  int timerfd;
} lgtm_timer_handle;

void lgtm_timer_proc_inner(void *timer_hd) {
  lgtm_timer_handle *timer_handle = (lgtm_timer_handle *)(timer_hd);
  if (timer_handle == NULL || timer_handle->proc == NULL) {
    return;
  }

  int value;
  read(timer_handle->timerfd, value, sizeof(int));

  timer_handle->proc(timer_handle->argv);
}

int lgtm_timer_param_valid(char *name, uint interval, lgtm_timer_callback proc,
                           int epoll_fd) {
  if (name == NULL || name[0] == '\0') {
    lgtm_log_error("lgtm timer create error: name is empty!");
    return LGTM_ERR;
  } else if (strlen(name) >= LGTM_NAME_MAX) {
    lgtm_log_error("lgtm timer create error: name is too long!");
    return LGTM_ERR;
  }

  if (proc == NULL) {
    lgtm_log_error("lgtm timer create error: name[%s] porc is empty!", name);
    return LGTM_ERR;
  }

  if (interval <= 0) {
    lgtm_log_error("lgtm timer create error: name[%s] interval is vilid!",
                   name);
    return LGTM_ERR;
  }

  if (epoll_fd == -1) {
    lgtm_log_error("lgtm timer create error: name[%s] epollfd is vilid!", name);
    return LGTM_ERR;
  }

  return LGTM_OK;
}

lgtm_timer_handle *lgtm_timer_handle_create(char *name, uint interval,
                                            lgtm_timer_callback proc,
                                            void *argv, int epoll_fd) {
  lgtm_timer_handle *timer_handle =
      (lgtm_timer_handle *)malloc(sizeof(lgtm_timer_handle));
  if (timer_handle == NULL) {
    lgtm_log_error("lgtm timer create error: name[%s] create handle fail!",
                   name);
    return NULL;
  }

  memset(timer_handle, 0, sizeof(lgtm_timer_handle));
  strncpy(timer_handle->name, name, LGTM_NAME_MAX - 1);
  timer_handle->proc = proc;
  timer_handle->argv = argv;
  timer_handle->interval = interval;
  timer_handle->callback = lgtm_timer_proc_inner;
  timer_handle->timer_handle->timerfd =
      timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK);
  if (timer_handle->timerfd == -1) {
    lgtm_log_error("lgtm timer create error: name[%s] create timerfd fail!",
                   name);
    free(timer_handle);
    return NULL;
  }

  struct epoll_event event = {
      EPOLLIN,
      {timer_handle, timer_handle->timerfd},
  };
  if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, timer_handle->timerfd, &event) != 0) {
    lgtm_log_error("lgtm timer create error: name[%s] epoll add fail!", name);
    close(timer_handle->timerfd);
    free(timer_handle);
    return NULL;
  }

  return timer_handle;
}

int lgtm_timer_create(char *name, uint interval, lgtm_timer_callback proc,
                      void *argv, int epoll_fd, lgtm_ptr *timer_hd) {
  if (lgtm_timer_param_valid(name, interval, proc, epoll_fd) == LGTM_OK) {
    return LGTM_ERR;
  }

  lgtm_timer_handle *timer_handle =
      lgtm_timer_handle_create(name, interval, proc, argv, epoll_fd);
  if (timer_handle == NULL) {
    return LGTM_ERR;
  }

  *timer_hd = timer_handle;

  return LGTM_OK;
}

int lgtm_timer_start(lgtm_ptr timer_hd) {
  if (timer_hd == NULL) {
    lgtm_log_error("lgtm timer start error:  timer handle is null!");
    return LGTM_ERR;
  }

  lgtm_timer_handle *timer_handle = (lgtm_timer_handle *)timer_hd;
  struct itimerspec ts = {
      {timer_hd->interval, 0},
      {timer_hd->interval, 0},
  };

  if (timerfd_settime(timer_handle->timerfd, TFD_TIMER_ABSTIME, &ts, NULL) !=
      0) {
    lgtm_log_error("lgtm timer start error: name[%s] timerfd set fail!",
                   timer_handle->name);
    return LGTM_ERR;
  }

  return LGTM_OK;
}
