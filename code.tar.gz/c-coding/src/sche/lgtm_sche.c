#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <sys/epoll.h>
#include <sys/timerfd.h>
#include <sys/time.h>

#include "lgtm_config.h"
#include "lgtm_log.h"

#define SCHE_ENVENT_MAX 5

typedef struct {
  pthread_mutex_t mutex;
  char name[LGTM_PATH_MAX];
  pthread_t tid;
  int epoll_fd;
  int timer_fd;
  // timer group
  // list task;
} lgtm_sche;

// todo 全局调度列表 加锁

int lgtm_sche_param_init(lgtm_sche *sche, char *name) {
  if (name == NULL || name[0] == '\0' || strlen(name) >= LGTM_NAME_MAX) {
    lgtm_log_error("lgtm sche create error: name[%s] is invalid!", name);
    return LGTM_ERR;
  }

  strncpy(sche->name, name, LGTM_NAME_MAX - 1);
  if (pthread_mutex_init(&sche->mutex, NULL) != 0) {
    lgtm_log_error("lgtm sche create error: name[%s] mutex init fail!", name);
    return LGTM_ERR;
  }

  sche->epoll_fd = epoll_create(SCHE_ENVENT_MAX);
  if (sche->epoll_fd < 0) {
    lgtm_log_error("lgtm sche create error: name[%s] epoll fd create fail!",
                   name);
    return LGTM_ERR;
  }

  sche->timer_fd = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK);
  if (sche->timer_fd == -1) {
    lgtm_log_error("lgtm sche create error: name[%s] timer fd create fail!",
                   name);
    free(timer_handle);
    return NULL;
  }

  sche->tid = NULL;
  return LGTM_OK;
}

void lgtm_sche_pthread_proc(void *argv) {
  if (argv == NULL) {
    return;
  }

  lgtm_sche *sche = (lgtm_sche *)argv;
  if (sche == NULL) {
    return;
  }

  prctl(PR_SET_NAME, sche->name);

  int cnt = 0;
  int i;
  struct epoll_event events[SCHE_ENVENT_MAX];
  for (;;) {
    cnt = epoll_wait(sche->epoll_fd, events, SCHE_ENVENT_MAX, 0);
    for (i = 0; i < cnt; ++i) {
      events[i].data.ptr;
    }
  }
}

int lgtm_sche_pthread_create(lgtm_sche *sche) {
  if (pthread_create(&sche->tid, NULL, lgtm_sche_pthread_proc, sche) != 0) {
    lgtm_log_error("lgtm sche create error: name[%s] create pthread fail!",
                   sche->name);
    return LGTM_ERR;
  }

  pthread_detach(sche->tid);

  return LGTM_OK;
}

int lgtm_sche_create(char *name) {
  lgtm_sche *sche = malloc(sizeof(lgtm_sche));
  if (sche == NULL) {
    lgtm_log_error("lgtm sche create error: name[%s] create sche handle fail!",
                   name);
    return LGTM_ERR;
  }

  if (lgtm_sche_param_init(sche, name) != LGTM_OK) {
    goto err;
  }

  if (lgtm_sche_pthread_create(sche) != LGTM_OK) {
    goto err;
  }

  // todo 全局调度列表

  return LGTM_OK;

err:
  // close(sche->timer_fd);
  // close(sche->epoll_fd);
  free(sche);
  return LGTM_ERR;
}