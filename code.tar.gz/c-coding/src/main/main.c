#include <stdio.h>

#include "lgtm_frame.h"

int main() {
  int ret;

  ret = lgtm_frame_main();
  if (ret != LGTM_OK) {
    return ret;
  }

  while (1) {
    sleep(MAIN_SLEEP_TIME);
  }
}