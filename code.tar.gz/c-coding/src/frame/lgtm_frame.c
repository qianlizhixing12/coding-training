#include "lgtm_config.h"
#include "lgtm_mnt.h"
// #include "lgtm_timer.h"
#include "lgtm_frame.h"

int lgtm_frame_main() {
  int ret = lgtm_mnt_init();
  if (ret != LGTM_OK) {
    return ret;
  }

  // lgtm_ptr timer_hd = NULL;
  // if (lgtm_timer_create("test", 5, NULL, "WWW.COM", epoll_fd, &timer_hd) !=
  //     LGTM_OK) {
  //   return ret;
  // }
  // if ()

  return LGTM_OK;
}