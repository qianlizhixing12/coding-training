#ifndef __LGTM_FRAME_H__
#define __LGTM_FRAME_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "lgtm_config.h"

extern int lgtm_frame_main();

#ifdef __cplusplus
}
#endif

#endif