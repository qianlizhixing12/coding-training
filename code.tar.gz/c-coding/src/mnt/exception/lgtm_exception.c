#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <execinfo.h>
#include <string.h>

#include "lgtm_config.h"
#include "lgtm_log.h"
#include "lgtm_exception.h"

#define LGTM_LOG_EXCEPTION 4

#define LGTM_EXCEPTION_HANDLE_NUM 5

typedef struct {
  lgtm_exception_cb *cb;
  void *argv;
} lgtm_exception_handle_node;

typedef struct {
  pthread_mutex_t mutex;
  lgtm_exception_handle_node handles[LGTM_EXCEPTION_HANDLE_NUM];
  uint handle_cur;
} lgtm_exception;

static lgtm_exception g_exception;

void lgtm_exception_trace(int signal_type) {
  void *buffer[100];
  int trace_id = backtrace(buffer, 1024);
  char **info = backtrace_symbols(buffer, trace_id);
  if (NULL == info) {
    return;
  }

  lgtm_log_write(LGTM_LOG_EXCEPTION,
                 "################# trace_info_%d ##################",
                 signal_type);
  int i = 0;
  for (i = 0; i < trace_id; i++) {
    lgtm_log_write(LGTM_LOG_EXCEPTION, "%s", info[i]);
  }
  lgtm_log_write(LGTM_LOG_EXCEPTION,
                 "################# trace_info_%d ##################",
                 signal_type);
  lgtm_log_flush(NULL);
}

void lgtm_exception_proc(int signal_type) {
  int i;
  lgtm_exception_handle_node node;

  pthread_mutex_lock(&g_exception.mutex);

  for (i = 0; i < LGTM_EXCEPTION_HANDLE_NUM; ++i) {
    node = g_exception.handles[i];
    if (node.cb == NULL) {
      return;
    }
    node.cb(node.argv);
  }

  lgtm_exception_trace(signal_type);
  pthread_mutex_unlock(&g_exception.mutex);
  exit(0);
}

int lgtm_exception_init() {
  signal(SIGHUP, lgtm_exception_proc);
  signal(SIGINT, lgtm_exception_proc);
  signal(SIGQUIT, lgtm_exception_proc);
  signal(SIGILL, lgtm_exception_proc);
  signal(SIGTRAP, lgtm_exception_proc);
  signal(SIGABRT, lgtm_exception_proc);
  signal(SIGBUS, lgtm_exception_proc);
  signal(SIGFPE, lgtm_exception_proc);
  signal(SIGKILL, lgtm_exception_proc);
  signal(SIGSEGV, lgtm_exception_proc);
  signal(SIGPIPE, lgtm_exception_proc);
  signal(SIGTERM, lgtm_exception_proc);

  lgtm_log_info("exception init success.");

  return LGTM_OK;
}

void lgtm_exception_handle_add(lgtm_exception_cb *cb, void *argv) {
  pthread_mutex_lock(&g_exception.mutex);

  if (g_exception.handle_cur < LGTM_EXCEPTION_HANDLE_NUM) {
    g_exception.handles[g_exception.handle_cur].cb = cb;
    g_exception.handles[g_exception.handle_cur].argv = argv;
    ++g_exception.handle_cur;
  }

  pthread_mutex_unlock(&g_exception.mutex);
}
