#ifndef __LGTM_EXCEPTION_H__
#define __LGTM_EXCEPTION_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef void(lgtm_exception_cb)(void *);

int lgtm_exception_init();
void lgtm_exception_handle_add(lgtm_exception_cb *cb, void *argv);

#ifdef __cplusplus
}
#endif

#endif // __LGTM_EXCEPTION_H__
