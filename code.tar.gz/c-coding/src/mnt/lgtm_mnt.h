#ifndef __LGTM_MNT_H__
#define __LGTM_MNT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#include "lgtm_config.h"

int lgtm_mnt_init();

#ifdef __cplusplus
}
#endif

#endif /* __LGTM_MNT_H__*/
