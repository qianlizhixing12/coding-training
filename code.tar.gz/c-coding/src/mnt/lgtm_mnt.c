#include "lgtm_log.h"
#include "lgtm_exception.h"
#include "lgtm_mnt.h"

int lgtm_mnt_init() {
  int ret;

  ret = lgtm_log_init();
  if (ret != LGTM_OK) {
    return ret;
  }

  ret = lgtm_exception_init();
  if (ret != LGTM_OK) {
    return ret;
  }

  lgtm_exception_handle_add(lgtm_log_flush, lgtm_log_get());
  return LGTM_OK;
}