#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <assert.h>

#include "lgtm_config.h"
#include "lgtm_log.h"

/* generic error */
#define error_display(...)                                                     \
  do {                                                                         \
    fprintf(stderr, __VA_ARGS__);                                              \
    assert(0);                                                                 \
  } while (0)

#define LGTM_LOG_LINE_SIZE 1024
#define LGTM_LOG_MAX_FILE_SIZE 102400 // byte
#define LGTM_LOG_MAX_BACK_NUM 200
#define LGTM_LOG_IO_BUFFER_SIZE 10240

typedef struct {
  pthread_mutex_t mutex;
  char file_path[LGTM_PATH_MAX];
  FILE *file_handle;
  char io_buf[LGTM_LOG_IO_BUFFER_SIZE];
  size_t io_cap;
  size_t max_file_size;
  size_t max_bak_num;
  size_t cur_file_size;
  size_t cur_bak_num;
} lgtm_logger;

static lgtm_logger g_log;

static const char *const severity[] = {
    "DEBUG", "INFO", "WARN", "ERROR", "EXCEPTION",
};

uint64_t _get_file_size(const char *fullfilepath) {
  int ret;
  struct stat sbuf;
  ret = stat(fullfilepath, &sbuf);
  if (ret || !S_ISREG(sbuf.st_mode))
    return 0;
  return (uint64_t)sbuf.st_size;
}

void _backup_file() {
  char new_filename[LGTM_PATH_MAX] = {0};

  (void)sprintf(new_filename, "%s.bak%lu", g_log.file_path,
                g_log.cur_bak_num % g_log.max_bak_num);
  rename(g_log.file_path, new_filename);
}

void _update_file() {
  if (!g_log.file_handle)
    return;

  fclose(g_log.file_handle);
  g_log.file_handle = NULL;
  if (g_log.max_bak_num == 0) { // without backup
    remove(g_log.file_path);
  } else {
    _backup_file();
  }
  g_log.cur_bak_num++;
  g_log.cur_file_size = 0;
}

void _write_file(char *msg, size_t len) {
  pthread_mutex_lock(&(g_log.mutex));

  if (!g_log.file_handle) {
    g_log.file_handle = fopen(g_log.file_path, "a+");
    if (!g_log.file_handle)
      return;
    if (setvbuf(g_log.file_handle, g_log.io_buf, _IOFBF, g_log.io_cap) != 0)
      return;
  }

  size_t print_size = fwrite(msg, sizeof(char), len, g_log.file_handle);
  if (print_size != len) {
    error_display("Failed to write the file path(%s), len(%lu)\n",
                  g_log.file_path, print_size);
    return;
  }
  g_log.cur_file_size += print_size;

  if (g_log.cur_file_size > g_log.max_file_size) {
    _update_file();
  }

  pthread_mutex_unlock(&(g_log.mutex));
}

void *lgtm_log_get() { return &g_log; }

void lgtm_log_flush(void *argv) {
  lgtm_logger *log = (lgtm_logger *)argv;

  if (log == NULL) {
    log = &g_log;
  }

  if (log->file_handle == NULL) {
    return;
  }

  pthread_mutex_lock(&(log->mutex));
  fclose(log->file_handle);
  log->file_handle = NULL;
  pthread_mutex_unlock(&(log->mutex));
}

int lgtm_log_init() {
  const char *log_file;
  int ret;

  ret = pthread_mutex_init(&(g_log.mutex), NULL);
  assert(ret == 0);
  // pthread_mutex_destroy(&(g_log.mutex));
  pthread_mutex_lock(&(g_log.mutex));

  log_file = getenv("LGTM_LOG");
  if (log_file == NULL || log_file[0] == '\0' ||
      strlen(log_file) >= LGTM_PATH_MAX) {
    goto err;
  }
  strncpy(g_log.file_path, log_file, LGTM_PATH_MAX);

  g_log.max_file_size = LGTM_LOG_MAX_FILE_SIZE;
  g_log.max_bak_num = LGTM_LOG_MAX_BACK_NUM;
  g_log.cur_file_size = _get_file_size(g_log.file_path);
  g_log.cur_bak_num = 0;
  g_log.io_cap = LGTM_LOG_IO_BUFFER_SIZE;

  pthread_mutex_unlock(&(g_log.mutex));

  lgtm_log_info("log init success.");
  return LGTM_OK;

err:
  pthread_mutex_unlock(&(g_log.mutex));
  return LGTM_ERR;
}

void lgtm_log_write(uint level, const char *format, ...) {
  if (format == NULL) {
    return;
  }

  char log_msg[LGTM_LOG_LINE_SIZE] = {0};

  time_t rawtime = time(NULL);
  struct tm timeinfo;
  localtime_r(&rawtime, &timeinfo);

  int info_len =
      snprintf(log_msg, LGTM_LOG_LINE_SIZE,
               "%04d-%02d-%02d %02d:%02d:%02d [pid:%ld][tid:%ld][%s]: ",
               timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday,
               timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec,
               syscall(SYS_getpid), syscall(SYS_gettid), severity[level]);
  va_list args;
  va_start(args, format);
  int total_len = vsnprintf(log_msg + info_len, LGTM_LOG_LINE_SIZE - info_len,
                            format, args);
  va_end(args);
  int tail_len = snprintf(log_msg + info_len + total_len,
                          LGTM_LOG_LINE_SIZE - info_len - total_len, "\n");

  if (total_len <= 0 || info_len <= 0 || tail_len <= 0 ||
      total_len + info_len + tail_len > LGTM_LOG_LINE_SIZE) {
    error_display("Failed to vsnprintf a text entry: (total_len) %d\n",
                  total_len);
    return;
  }
  total_len += info_len + tail_len;

  _write_file(log_msg, total_len);
}
