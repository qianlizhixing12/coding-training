class Solution:

    def replaceSpaces(self, S: str, length: int) -> str:
        return S[:length].replace(' ', '%20')