### coding-training-website

- 编程训练
- c c++解题
- 使用单元测试，而不是main函数
- web.md 题目及链接
- web/num.c(num.cpp) 题解源码及思路描述

### web

- [leetcode](https://leetcode-cn.com/)
- [nowcoder](https://www.nowcoder.com/)
- [projecteuler](https://projecteuler.net/)

### note

- 解题方法不一定是性能最高的，力求简洁可读，力求常见问题只有一个第一模板